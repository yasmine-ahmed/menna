<?php
	//normal usage
	$galleryStr1 = "{lightgallery type=url path=https://farm4.staticflickr.com/3721/13418148685_dfbfa07d42_b_d.jpg}Hello World{/lightgallery}";
	//show a gallery from local
	$galleryStr2 = "{lightgallery type=local path=images/my_images}{/lightgallery} ";
	//show a gallery from local for 1 pic
	$galleryStr21 = "{lightgallery type=local path=images/my_images/3.jpg}{/lightgallery} ";
	//show a gallery from local with preview size
	$galleryStr3 = "{lightgallery type=local path=images/my_images previewWidth=100}{/lightgallery} ";
	//show a gallery from local with preview size
	$galleryStr31 = "{lightgallery type=local path=images/my_images previewHeight=100}{/lightgallery} ";
	//show a gallery from local with thumbnail local
	$galleryStr4 = "{lightgallery type=\"local\" path=\"images/my_images\" thumbnailPath=\"images/thumb_folder\"}{/lightgallery} ";
	//show a gallery from flickr, small thumbnail with big image
	$galleryStr5 = "{lightgallery type=\"flickr\" flickr=\"25357685@N04\" flickrSmallThumbs=\"true\" flickrLargeImages=\"true\"}{/lightgallery}";
	//show a gallery from flickr, medium size with 7 pics
	$galleryStr5 = "{lightgallery type=\"flickr\" flickr=\"25357685@N04\" flickrNumberOfImages=\"7\"}{/lightgallery}";
	//show a gallery from facebook
	//show a gallery from google picasal
	
	$html="<html><body>"."<div>".$galleryStr1."</div>"
		."<div>".$galleryStr21."</div>"
		."<div>".$galleryStr31."</div>"
		."</body></html>";
	$html = onContentPrepare($html);
	echo $html;

	function onContentPrepare( $text )
	{
        // Plugin code goes here.
        // You can access parameters via $this->params.
		
		// expression to search for
		$regex = "#{lightgallery(.*?)}(.*?){/lightgallery}#s";

		// find all instances of plugin and put in $matches
		$matches = array();
		preg_match_all( $regex, $text, $matches, PREG_SET_ORDER );
		$num = sizeof($matches);
		
		$galleryJS = "";
		if($num > 0)
		{
			$galleryJS = "<script src=\"js/jquery-1.11.0.min.js\"></script>";
			$galleryJS .= "<script src=\"js/lightbox.min.js\"></script>";
			$galleryJS .= "<link href=\"css/lightbox.css\" rel=\"stylesheet\" />";
		}
		
		for ($i = 0; $i < $num; $i++) { 
			// generate PayPal form
			$galleryHTML = generateGallery($matches[$i], $i);
			$text = preg_replace("{".$matches[$i][0]."}", $galleryHTML , $text, 1);
		}
		
		$text .= $galleryJS;
		
		return $text;
	}
	
	function generateGallery($options, $galleryNumber)
	{
		$options[1] = str_replace (" ", "&", $options[1]); //replace space with &
		parse_str($options[1], $OptionArray);
		
		//gallery attribute
		$urlstr = array();
		if(empty($OptionArray['type']))
		{
			return "<strong>Light Gallery format is incorrect, type is missing!</strong>";
		}
		else if(empty($OptionArray['path']))
		{
			return "<strong>Light Gallery format is incorrect, path is missing!</strong>";
		}
		
		
		if(empty($OptionArray['previewWidth']))
		{
			if(empty($OptionArray['previewHeight']))
			{
				$OptionArray['previewWidth'] = 300;
				$OptionArray['previewHeight'] = "";
			}
			else
			{
				$OptionArray['previewWidth'] = "";
			}
		}
		else
		{
			$OptionArray['previewHeight'] = "";
		}

		switch($OptionArray['type'])
		{
			case "url":
				$urlstr[] = trim($OptionArray['path']);
				break;
			case "local":
				$path = trim($OptionArray['path']);
				if(file_exists($path))
				{
					$currentURL = 'http://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/';
					if(is_dir($path))
					{
						//loop the path and build image url
						$files = scandir($path);
						print_r($files);
						foreach($files as $file)
						{
							if(!is_dir($file))
							{
								$urlstr[] = $currentURL.$path."/".$file;
							}
						}
					}
					else
					{
						$urlstr[] = $currentURL.$path;
					}
				}
				else
				{
					return "<strong>Light Gallery cannot find your image path: <i>$path</i>!</strong>";
				}
				
				break;
			default:
				return $OptionArray['type']."<strong>Light Gallery Format is incorrect, path is missing!</strong>";
		}
		
		//find parameter
		$margin = "10px";
		$galleryText = "";
		foreach($urlstr as $k=>$v)
		{
			$galleryText .= "<a href=\"".$v."\" data-lightbox=\"image-1\" data-title=\"".$options[2]."\">"."<img style=\"margin: ".$margin.";\" src=\"".$v."\" width=\"".$OptionArray['previewWidth']."\" height=\"".$OptionArray['previewHeight']."\">"."</a>";
		}
		
		return $galleryText;
	}
?>